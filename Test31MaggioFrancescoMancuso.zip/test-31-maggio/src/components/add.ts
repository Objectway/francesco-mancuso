function increment(count:number){
    count++;
    return count;
}
export default increment;