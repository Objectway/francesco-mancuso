function sub(count:number){
    count--;
    return count;
}
export default sub;